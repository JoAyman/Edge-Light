import { useEffect, useRef } from 'react';
import { Chart, registerables } from 'chart.js';

Chart.register(...registerables);

export default function EdgeLight() {
  const chartRef = useRef<HTMLCanvasElement>(null);
  const deviceSliderRef = useRef<HTMLInputElement>(null);

  useEffect(() => {
    // Counter animation
    const animateCounters = () => {
      const counters = document.querySelectorAll('.counter');
      counters.forEach(counter => {
        const target = parseInt(counter.getAttribute('data-target') || '0');
        const duration = 2000;
        const step = target / (duration / 16);
        let current = 0;
        
        const timer = setInterval(() => {
          current += step;
          if (current >= target) {
            counter.textContent = target.toString();
            clearInterval(timer);
          } else {
            counter.textContent = Math.floor(current).toString();
          }
        }, 16);
      });
    };

    // Initialize chart
    const initChart = () => {
      if (!chartRef.current) return;
      
      const ctx = chartRef.current.getContext('2d');
      if (!ctx) return;

      new Chart(ctx, {
        type: 'bar',
        data: {
          labels: ['Latency (ms)', 'FPS', 'Memory (MB)', 'Accuracy (mAP)', 'Energy (mJ)'],
          datasets: [{
            label: 'Baseline CPU (FP32)',
            data: [320, 3.1, 1024, 45.2, 1600],
            backgroundColor: 'rgba(239, 68, 68, 0.6)',
            borderColor: 'rgba(239, 68, 68, 1)',
            borderWidth: 2
          }, {
            label: 'EdgeLight Optimized (INT8)',
            data: [65, 15.4, 328, 43.8, 520],
            backgroundColor: 'rgba(34, 197, 94, 0.6)',
            borderColor: 'rgba(34, 197, 94, 1)',
            borderWidth: 2
          }]
        },
        options: {
          responsive: true,
          maintainAspectRatio: true,
          plugins: {
            legend: {
              labels: {
                color: '#e2e8f0',
                font: {
                  size: 14,
                  family: 'Inter'
                }
              }
            }
          },
          scales: {
            y: {
              beginAtZero: true,
              grid: {
                color: 'rgba(255, 255, 255, 0.1)'
              },
              ticks: {
                color: '#9ca3af'
              }
            },
            x: {
              grid: {
                color: 'rgba(255, 255, 255, 0.1)'
              },
              ticks: {
                color: '#9ca3af'
              }
            }
          }
        }
      });
    };

    animateCounters();
    initChart();
    updateCalculator(100);
  }, []);

  const scrollToSection = (sectionId: string) => {
    document.getElementById(sectionId)?.scrollIntoView({ behavior: 'smooth' });
  };

  const updateCalculator = (value: number) => {
    const devices = parseInt(value.toString());
    const gpuCost = devices * 450;
    const cpuCost = devices * 75;
    const savings = gpuCost - cpuCost;
    const savingsPercent = Math.round((savings / gpuCost) * 100);
    
    const deviceCountEl = document.getElementById('deviceCount');
    const gpuCostEl = document.getElementById('gpuCost');
    const cpuCostEl = document.getElementById('cpuCost');
    const totalSavingsEl = document.getElementById('totalSavings');
    const savingsPercentEl = document.getElementById('savingsPercent');
    
    if (deviceCountEl) deviceCountEl.textContent = devices.toString();
    if (gpuCostEl) gpuCostEl.textContent = gpuCost.toLocaleString();
    if (cpuCostEl) cpuCostEl.textContent = cpuCost.toLocaleString();
    if (totalSavingsEl) totalSavingsEl.textContent = savings.toLocaleString();
    if (savingsPercentEl) savingsPercentEl.textContent = savingsPercent + '%';
  };

  const toggleAccordion = (e: React.MouseEvent<HTMLButtonElement>) => {
    const button = e.currentTarget;
    const content = button.nextElementSibling as HTMLElement;
    const icon = button.querySelector('svg');
    const allContents = document.querySelectorAll('.accordion-content');
    const allIcons = document.querySelectorAll('.accordion-trigger svg');
    
    allContents.forEach(c => {
      if (c !== content) {
        c.classList.remove('active');
      }
    });
    
    allIcons.forEach(i => {
      if (i !== icon) {
        (i as HTMLElement).style.transform = 'rotate(0deg)';
      }
    });
    
    content?.classList.toggle('active');
    if (content?.classList.contains('active') && icon) {
      (icon as HTMLElement).style.transform = 'rotate(180deg)';
    } else if (icon) {
      (icon as HTMLElement).style.transform = 'rotate(0deg)';
    }
  };

  return (
    <div className="min-h-screen bg-gradient-to-br from-[#0a0e27] to-[#1a1f3a] text-gray-100 font-sans">
      <style>{`
        .gradient-text {
          background: linear-gradient(135deg, #60a5fa 0%, #a78bfa 50%, #ec4899 100%);
          -webkit-background-clip: text;
          -webkit-text-fill-color: transparent;
          background-clip: text;
        }

        .glass-card {
          background: rgba(255, 255, 255, 0.05);
          backdrop-filter: blur(10px);
          border: 1px solid rgba(255, 255, 255, 0.1);
          border-radius: 16px;
          transition: all 0.3s ease;
        }

        .glass-card:hover {
          background: rgba(255, 255, 255, 0.08);
          border-color: rgba(96, 165, 250, 0.3);
          transform: translateY(-4px);
          box-shadow: 0 20px 60px rgba(96, 165, 250, 0.2);
        }

        .metric-card {
          background: linear-gradient(135deg, rgba(59, 130, 246, 0.1) 0%, rgba(139, 92, 246, 0.1) 100%);
          border: 1px solid rgba(96, 165, 250, 0.2);
          border-radius: 12px;
          padding: 24px;
          text-align: center;
        }

        @keyframes float {
          0%, 100% { transform: translateY(0px); }
          50% { transform: translateY(-20px); }
        }

        .floating {
          animation: float 6s ease-in-out infinite;
        }

        .grid-bg {
          background-image: 
            linear-gradient(rgba(96, 165, 250, 0.05) 1px, transparent 1px),
            linear-gradient(90deg, rgba(96, 165, 250, 0.05) 1px, transparent 1px);
          background-size: 50px 50px;
        }

        .accordion-content {
          max-height: 0;
          overflow: hidden;
          transition: max-height 0.3s ease;
        }

        .accordion-content.active {
          max-height: 1000px;
        }

        .tag {
          background: rgba(96, 165, 250, 0.2);
          color: #60a5fa;
          padding: 4px 12px;
          border-radius: 20px;
          font-size: 12px;
          font-weight: 600;
          display: inline-block;
        }

        .stage-card {
          position: relative;
          padding-left: 60px;
        }

        .stage-number {
          position: absolute;
          left: 0;
          top: 0;
          width: 48px;
          height: 48px;
          background: linear-gradient(135deg, #3b82f6 0%, #8b5cf6 100%);
          border-radius: 12px;
          display: flex;
          align-items: center;
          justify-content: center;
          font-weight: 700;
          font-size: 20px;
        }
      `}</style>

      {/* Navigation */}
      <nav className="fixed top-0 left-0 right-0 z-50 backdrop-blur-md bg-[#0a0e27]/80 border-b border-white/10">
        <div className="max-w-7xl mx-auto px-6 py-4 flex items-center justify-between">
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 bg-gradient-to-br from-blue-500 to-purple-600 rounded-lg flex items-center justify-center">
              <svg className="w-6 h-6 text-white" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                <path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M13 10V3L4 14h7v7l9-11h-7z" />
              </svg>
            </div>
            <span className="text-xl font-bold">EdgeLight</span>
          </div>
          
          <div className="hidden md:flex items-center gap-8">
            <button onClick={() => scrollToSection('features')} className="text-gray-300 hover:text-white transition">Features</button>
            <button onClick={() => scrollToSection('results')} className="text-gray-300 hover:text-white transition">Results</button>
            <button onClick={() => scrollToSection('architecture')} className="text-gray-300 hover:text-white transition">Architecture</button>
            <button onClick={() => scrollToSection('downloads')} className="text-gray-300 hover:text-white transition">Downloads</button>
          </div>
          
          <button className="bg-gradient-to-r from-blue-500 to-purple-600 text-white px-6 py-3 rounded-xl font-semibold hover:shadow-lg transition flex items-center gap-2">
            <svg className="w-5 h-5" fill="currentColor" viewBox="0 0 24 24">
              <path d="M12 0c-6.626 0-12 5.373-12 12 0 5.302 3.438 9.8 8.207 11.387.599.111.793-.261.793-.577v-2.234c-3.338.726-4.033-1.416-4.033-1.416-.546-1.387-1.333-1.756-1.333-1.756-1.089-.745.083-.729.083-.729 1.205.084 1.839 1.237 1.839 1.237 1.07 1.834 2.807 1.304 3.492.997.107-.775.418-1.305.762-1.604-2.665-.305-5.467-1.334-5.467-5.931 0-1.311.469-2.381 1.236-3.221-.124-.303-.535-1.524.117-3.176 0 0 1.008-.322 3.301 1.23.957-.266 1.983-.399 3.003-.404 1.02.005 2.047.138 3.006.404 2.291-1.552 3.297-1.23 3.297-1.23.653 1.653.242 2.874.118 3.176.77.84 1.235 1.911 1.235 3.221 0 4.609-2.807 5.624-5.479 5.921.43.372.823 1.102.823 2.222v3.293c0 .319.192.694.801.576 4.765-1.589 8.199-6.086 8.199-11.386 0-6.627-5.373-12-12-12z"/>
            </svg>
            GitHub
          </button>
        </div>
      </nav>

      {/* Hero Section */}
      <section className="min-h-screen flex items-center justify-center relative overflow-hidden grid-bg pt-24">
        <div className="absolute inset-0 overflow-hidden">
          <div className="absolute top-1/4 left-1/4 w-96 h-96 bg-blue-500 rounded-full filter blur-3xl opacity-10 floating"></div>
          <div className="absolute bottom-1/4 right-1/4 w-96 h-96 bg-purple-500 rounded-full filter blur-3xl opacity-10 floating" style={{animationDelay: '2s'}}></div>
        </div>
        
        <div className="max-w-6xl mx-auto px-6 text-center relative z-10">
          <div className="mb-6">
            <span className="tag">REVOLUTIONARY AI FRAMEWORK</span>
          </div>
          
          <h1 className="text-5xl md:text-7xl font-black mb-6 leading-tight">
            Run Heavy Vision Models<br/>
            <span className="gradient-text">on Lightweight CPUs</span>
          </h1>
          
          <p className="text-xl md:text-2xl text-gray-300 mb-12 max-w-4xl mx-auto">
            EdgeLight eliminates the need for expensive GPU edge modules. Achieve 2×–6× real-world speedup on Raspberry Pi & low-cost SBCs with minimal accuracy loss.
          </p>
          
          <div className="flex flex-wrap items-center justify-center gap-4 mb-16">
            <button onClick={() => scrollToSection('downloads')} className="bg-gradient-to-r from-blue-500 to-purple-600 text-white px-8 py-4 rounded-xl font-semibold hover:shadow-lg transition flex items-center gap-2">
              <svg className="w-5 h-5" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                <path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M4 16v1a3 3 0 003 3h10a3 3 0 003-3v-1m-4-4l-4 4m0 0l-4-4m4 4V4" />
              </svg>
              Download Framework
            </button>
            <button onClick={() => scrollToSection('demo')} className="bg-white/10 border border-white/20 text-white px-8 py-4 rounded-xl font-semibold hover:bg-white/15 transition flex items-center gap-2">
              <svg className="w-5 h-5" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                <path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M14.752 11.168l-3.197-2.132A1 1 0 0010 9.87v4.263a1 1 0 001.555.832l3.197-2.132a1 1 0 000-1.664z" />
              </svg>
              Watch Demo
            </button>
          </div>
          
          {/* Live Metrics Ticker */}
          <div className="grid grid-cols-1 md:grid-cols-4 gap-6 max-w-5xl mx-auto">
            <div className="metric-card">
              <div className="text-4xl font-bold gradient-text counter font-mono" data-target="6">0</div>
              <div className="text-sm text-gray-400 mt-2">Max Speedup</div>
            </div>
            <div className="metric-card">
              <div className="text-4xl font-bold gradient-text counter font-mono" data-target="75">0</div>
              <div className="text-sm text-gray-400 mt-2">% Memory Reduction</div>
            </div>
            <div className="metric-card">
              <div className="text-4xl font-bold gradient-text font-mono">$<span className="counter" data-target="550">0</span></div>
              <div className="text-sm text-gray-400 mt-2">Cost Savings per Unit</div>
            </div>
            <div className="metric-card">
              <div className="text-4xl font-bold gradient-text counter font-mono" data-target="20">0</div>
              <div className="text-sm text-gray-400 mt-2">FPS on Raspberry Pi</div>
            </div>
          </div>
        </div>
      </section>

      {/* Problem Statement */}
      <section className="py-24 px-6">
        <div className="max-w-6xl mx-auto">
          <div className="text-center mb-16">
            <h2 className="text-4xl md:text-5xl font-bold mb-6">The GPU Dependency Problem</h2>
            <p className="text-xl text-gray-300 max-w-3xl mx-auto">
              Running real-time vision models at the edge requires expensive GPU modules ($400-$700), making robotics and IoT vision applications prohibitively expensive at scale.
            </p>
          </div>
          
          <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
            <div className="glass-card p-8">
              <div className="flex items-center gap-4 mb-4">
                <div className="w-12 h-12 bg-red-500/20 rounded-lg flex items-center justify-center">
                  <svg className="w-6 h-6 text-red-400" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                    <path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M6 18L18 6M6 6l12 12" />
                  </svg>
                </div>
                <h3 className="text-2xl font-bold text-red-400">Traditional Approach</h3>
              </div>
              <ul className="space-y-3 text-gray-300">
                <li className="flex items-start gap-3">
                  <span className="text-red-400 mt-1">✗</span>
                  <span>Requires expensive GPU edge modules (Jetson Xavier $400-$700)</span>
                </li>
                <li className="flex items-start gap-3">
                  <span className="text-red-400 mt-1">✗</span>
                  <span>High power consumption (10-30W)</span>
                </li>
                <li className="flex items-start gap-3">
                  <span className="text-red-400 mt-1">✗</span>
                  <span>Limited deployment at scale due to cost</span>
                </li>
                <li className="flex items-start gap-3">
                  <span className="text-red-400 mt-1">✗</span>
                  <span>Complex thermal management required</span>
                </li>
              </ul>
            </div>
            
            <div className="glass-card p-8">
              <div className="flex items-center gap-4 mb-4">
                <div className="w-12 h-12 bg-green-500/20 rounded-lg flex items-center justify-center">
                  <svg className="w-6 h-6 text-green-400" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                    <path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M5 13l4 4L19 7" />
                  </svg>
                </div>
                <h3 className="text-2xl font-bold text-green-400">EdgeLight Solution</h3>
              </div>
              <ul className="space-y-3 text-gray-300">
                <li className="flex items-start gap-3">
                  <span className="text-green-400 mt-1">✓</span>
                  <span>Runs on $35-$100 SBCs (Raspberry Pi, ARM boards)</span>
                </li>
                <li className="flex items-start gap-3">
                  <span className="text-green-400 mt-1">✓</span>
                  <span>Low power consumption (3-5W)</span>
                </li>
                <li className="flex items-start gap-3">
                  <span className="text-green-400 mt-1">✓</span>
                  <span>Scalable deployment with 80-90% cost reduction</span>
                </li>
                <li className="flex items-start gap-3">
                  <span className="text-green-400 mt-1">✓</span>
                  <span>Passive cooling sufficient for most applications</span>
                </li>
              </ul>
            </div>
          </div>
        </div>
      </section>

      {/* Interactive Metrics Dashboard */}
      <section id="results" className="py-24 px-6 bg-gradient-to-b from-transparent to-blue-900/10">
        <div className="max-w-7xl mx-auto">
          <div className="text-center mb-16">
            <h2 className="text-4xl md:text-5xl font-bold mb-6">Real-World Performance Results</h2>
            <p className="text-xl text-gray-300 max-w-3xl mx-auto">
              YOLOv5-small object detection on Raspberry Pi 4 (ARM Cortex-A72, 4GB)
            </p>
          </div>
          
          {/* Performance Chart */}
          <div className="glass-card p-8 mb-12">
            <h3 className="text-2xl font-bold mb-6">Performance Comparison Chart</h3>
            <canvas ref={chartRef} height="100"></canvas>
          </div>
        </div>
      </section>

      {/* ROI Calculator */}
      <section className="py-24 px-6">
        <div className="max-w-4xl mx-auto">
          <div className="text-center mb-12">
            <h2 className="text-4xl md:text-5xl font-bold mb-6">ROI Calculator</h2>
            <p className="text-xl text-gray-300">
              Calculate your cost savings deploying EdgeLight at scale
            </p>
          </div>
          
          <div className="glass-card p-8">
            <div className="mb-8">
              <label className="block text-lg font-semibold mb-4">Number of Edge Devices to Deploy:</label>
              <input 
                ref={deviceSliderRef}
                type="range" 
                id="deviceSlider" 
                min="1" 
                max="1000" 
                defaultValue="100" 
                className="w-full h-2 bg-gray-700 rounded-lg appearance-none cursor-pointer"
                onChange={(e) => updateCalculator(parseInt(e.target.value))}
              />
              <div className="flex justify-between text-sm text-gray-400 mt-2">
                <span>1</span>
                <span id="deviceCount" className="font-bold text-2xl gradient-text">100</span>
                <span>1000</span>
              </div>
            </div>
            
            <div className="grid grid-cols-1 md:grid-cols-2 gap-6 mb-8">
              <div className="bg-red-500/10 border border-red-500/30 rounded-lg p-6">
                <h4 className="text-sm text-gray-400 mb-2">Traditional GPU Approach</h4>
                <p className="text-xs text-gray-500 mb-4">Jetson Xavier NX @ $450/unit</p>
                <div className="text-4xl font-bold text-red-400 font-mono">$<span id="gpuCost">45,000</span></div>
                <p className="text-sm text-gray-400 mt-2">Total Hardware Cost</p>
              </div>
              
              <div className="bg-green-500/10 border border-green-500/30 rounded-lg p-6">
                <h4 className="text-sm text-gray-400 mb-2">EdgeLight on CPU</h4>
                <p className="text-xs text-gray-500 mb-4">Raspberry Pi 4 (4GB) @ $75/unit</p>
                <div className="text-4xl font-bold text-green-400 font-mono">$<span id="cpuCost">7,500</span></div>
                <p className="text-sm text-gray-400 mt-2">Total Hardware Cost</p>
              </div>
            </div>
            
            <div className="bg-gradient-to-r from-green-500/20 to-blue-500/20 border-2 border-green-500/50 rounded-lg p-6 text-center">
              <h4 className="text-lg font-semibold mb-2">Your Total Savings</h4>
              <div className="text-5xl font-black gradient-text font-mono mb-2">$<span id="totalSavings">37,500</span></div>
              <p className="text-gray-300">
                That's <span id="savingsPercent" className="font-bold text-green-400">83%</span> cost reduction!
              </p>
              <p className="text-sm text-gray-400 mt-4">
                Plus <span className="font-bold">70% lower ongoing energy costs</span>
              </p>
            </div>
          </div>
        </div>
      </section>

      {/* Downloads Section */}
      <section id="downloads" className="py-24 px-6 bg-gradient-to-b from-transparent to-purple-900/10">
        <div className="max-w-6xl mx-auto">
          <div className="text-center mb-12">
            <h2 className="text-4xl md:text-5xl font-bold mb-6">Download Framework & Artifacts</h2>
            <p className="text-xl text-gray-300">
              Complete package with models, scripts, datasets, and documentation
            </p>
          </div>
          
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
            {[
              { icon: 'M9 12h6m-6 4h6m2 5H7a2 2 0 01-2-2V5a2 2 0 012-2h5.586a1 1 0 01.707.293l5.414 5.414a1 1 0 01.293.707V19a2 2 0 01-2 2z', title: 'Optimized Models', desc: 'quantized_int8.onnx, pruned.onnx', size: '142 MB', color: 'blue' },
              { icon: 'M10 20l4-16m4 4l4 4-4 4M6 16l-4-4 4-4', title: 'Runtime Scripts', desc: 'run_optimized.sh, edge_runtime.py', size: '2.4 MB', color: 'purple' },
              { icon: 'M4 7v10c0 2.21 3.582 4 8 4s8-1.79 8-4V7M4 7c0 2.21 3.582 4 8 4s8-1.79 8-4M4 7c0-2.21 3.582-4 8-4s8 1.79 8 4', title: 'Calibration Dataset', desc: '500 images for quantization', size: '385 MB', color: 'pink' },
              { icon: 'M9 17v-2m3 2v-4m3 4v-6m2 10H7a2 2 0 01-2-2V5a2 2 0 012-2h5.586a1 1 0 01.707.293l5.414 5.414a1 1 0 01.293.707V19a2 2 0 01-2 2z', title: 'Benchmark Results', desc: 'metrics.csv, profiler logs', size: '8.2 MB', color: 'green' },
              { icon: 'M12 6.253v13m0-13C10.832 5.477 9.246 5 7.5 5S4.168 5.477 3 6.253v13C4.168 18.477 5.754 18 7.5 18s3.332.477 4.5 1.253m0-13C13.168 5.477 14.754 5 16.5 5c1.747 0 3.332.477 4.5 1.253v13C19.832 18.477 18.247 18 16.5 18c-1.746 0-3.332.477-4.5 1.253', title: 'Documentation', desc: 'README, API docs, tutorials', size: '12 MB', color: 'yellow' },
              { icon: 'M4 16v1a3 3 0 003 3h10a3 3 0 003-3v-1m-4-4l-4 4m0 0l-4-4m4 4V4', title: 'Complete Package', desc: 'All files + Docker image', size: '1.2 GB', color: 'blue', highlighted: true }
            ].map((item, idx) => (
              <div key={idx} className={`glass-card p-6 ${item.highlighted ? 'border-2 border-blue-500/50' : ''}`}>
                <div className={`w-12 h-12 bg-${item.color}-500/20 rounded-lg flex items-center justify-center mb-4`}>
                  <svg className={`w-6 h-6 text-${item.color}-400`} fill="none" stroke="currentColor" viewBox="0 0 24 24">
                    <path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d={item.icon} />
                  </svg>
                </div>
                <h3 className="font-bold text-lg mb-2">{item.title}</h3>
                <p className="text-sm text-gray-400 mb-4">{item.desc}</p>
                <div className="flex items-center justify-between">
                  <span className="text-xs text-gray-500 font-mono">{item.size}</span>
                  <button className={item.highlighted ? 'bg-blue-500 hover:bg-blue-600 text-white px-4 py-2 rounded-lg text-sm font-semibold transition' : 'text-blue-400 hover:text-blue-300 text-sm font-semibold'}>
                    {item.highlighted ? 'Download All' : 'Download →'}
                  </button>
                </div>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* Footer */}
      <footer className="py-16 px-6 border-t border-white/10">
        <div className="max-w-6xl mx-auto">
          <div className="grid grid-cols-1 md:grid-cols-3 gap-12 mb-12">
            <div>
              <div className="flex items-center gap-3 mb-4">
                <div className="w-10 h-10 bg-gradient-to-br from-blue-500 to-purple-600 rounded-lg flex items-center justify-center">
                  <svg className="w-6 h-6 text-white" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                    <path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M13 10V3L4 14h7v7l9-11h-7z" />
                  </svg>
                </div>
                <span className="text-xl font-bold">EdgeLight</span>
              </div>
              <p className="text-gray-400 text-sm">
                Revolutionary software framework enabling heavy vision models on lightweight CPUs.
              </p>
            </div>
            
            <div>
              <h4 className="font-bold mb-4">Quick Links</h4>
              <ul className="space-y-2 text-sm">
                <li><button onClick={() => scrollToSection('features')} className="text-gray-400 hover:text-white transition">Features</button></li>
                <li><button onClick={() => scrollToSection('results')} className="text-gray-400 hover:text-white transition">Performance Results</button></li>
                <li><button onClick={() => scrollToSection('downloads')} className="text-gray-400 hover:text-white transition">Downloads</button></li>
              </ul>
            </div>
            
            <div>
              <h4 className="font-bold mb-4">Resources</h4>
              <ul className="space-y-2 text-sm">
                <li><a href="#" className="text-gray-400 hover:text-white transition">GitHub Repository</a></li>
                <li><a href="#" className="text-gray-400 hover:text-white transition">Documentation</a></li>
                <li><a href="#" className="text-gray-400 hover:text-white transition">API Reference</a></li>
              </ul>
            </div>
          </div>
          
          <div className="border-t border-white/10 pt-8 flex flex-col md:flex-row items-center justify-between gap-4">
            <p className="text-sm text-gray-500">
              © 2025 EdgeLight Framework. All rights reserved.
            </p>
          </div>
        </div>
      </footer>
    </div>
  );
}